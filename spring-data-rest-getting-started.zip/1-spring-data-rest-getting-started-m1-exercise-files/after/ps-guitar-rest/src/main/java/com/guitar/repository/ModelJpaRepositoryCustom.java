package com.guitar.repository;

public interface ModelJpaRepositoryCustom {
	void aCustomMethod();
}
