Java runs on just about every platform out there.

System Requirements:
- JDK 1.8 or later
- Maven 3 or later
- GIT

Development Requirements:
- A text editor or IDE of your choice
- Knowledge with using a terminal or command prompt
- Knowledge of Maven
- Knowledge of Spring
- Knowledge of JPA
- Knowledge of REST
